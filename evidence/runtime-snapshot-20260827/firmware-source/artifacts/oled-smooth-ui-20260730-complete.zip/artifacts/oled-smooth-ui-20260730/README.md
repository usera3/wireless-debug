# OLED Smooth UI Stable Archive

Created: 2026-07-30 (Asia/Shanghai)

- Git tag: `stable-oled-smooth-ui-20260730`
- Commit: `80ad0d4f58fe3cf27d97cf59076777251f17a187`
- Target: ESP32-S3, 8 MB flash
- Display: SSD1315 128x64, I2C 400 kHz
- App image size: `0x199aa0` bytes in the ESP-IDF size report
- App partition free space: 36%

## Validation

- OLED motion and normal startup were verified on the physical device.
- App-only flash at `0x10000` completed with esptool data-hash verification.
- Smooth selection cursor and page transitions were confirmed by the user.
- OLED motion, I2C speed, layout, and WiFi status regressions passed.
- ESP-IDF 6.0 build completed successfully.

## Contents

- `flash/uart_ble_wifi.bin`: application image, offset `0x10000`
- `flash/storage.bin`: SPIFFS web image, offset `0x290000`
- `flash/bootloader/bootloader.bin`: bootloader, offset `0x0`
- `flash/partition_table/partition-table.bin`: partition table, offset `0x8000`
- `flash/flash_args`: complete esptool argument file
- `flash/flasher_args.json`: machine-readable flash layout
- `source/wireless-debug-fw-source.zip`: source tree at the stable tag
- `source/wireless-debug-fw.bundle`: self-contained Git history and stable tag
- `SHA256SUMS`: integrity hashes for every recovery artifact

## Verify Archive

From this directory:

```bash
sha256sum -c SHA256SUMS
git bundle verify source/wireless-debug-fw.bundle
```

## Flash App Only

Use this for restoring the verified OLED firmware without changing the web SPIFFS:

```text
D:\Users\sunqi39\.espressif\python_env\idf6.0_py3.11_env\Scripts\python.exe -m esptool --chip esp32s3 -p COM4 -b 460800 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-freq 80m --flash-size 8MB 0x10000 uart_ble_wifi.bin
```

Run the command from the `flash` directory. Confirm the actual COM port before flashing.

## Full Flash Restore

Run from the `flash` directory after putting the board in download mode:

```text
D:\Users\sunqi39\.espressif\python_env\idf6.0_py3.11_env\Scripts\python.exe -m esptool --chip esp32s3 -p COM4 -b 460800 --before default-reset --after hard-reset write-flash "@flash_args"
```

## Restore Source

The ZIP is the simplest source snapshot. To recover Git history and the tag:

```bash
git clone source/wireless-debug-fw.bundle restored-wireless-debug-fw
git -C restored-wireless-debug-fw checkout -b restored-oled-ui stable-oled-smooth-ui-20260730
```

## Known Edge Case

If a forward page transition is immediately reversed inside its 200 ms animation,
the returning content can finish along the original direction. It does not jump or
crash and was not visible in normal physical-button use. A future dual-page
transition layer can remove this cosmetic corner case.
